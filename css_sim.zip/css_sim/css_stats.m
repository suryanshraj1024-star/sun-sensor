function st = css_stats(e)
%CSS_STATS Summary statistics of angular errors (deg). p997 is the
%   99.7th percentile, the usual "3-sigma" figure for non-Gaussian errors.
e = sort(e(:));
if isempty(e)
    st = struct('mean',NaN,'rms',NaN,'p95',NaN,'p997',NaN,'max',NaN);
    return
end
n = numel(e);
st.mean = mean(e);
st.rms  = sqrt(mean(e.^2));
st.p95  = e(max(1, ceil(0.95*n)));
st.p997 = e(max(1, ceil(0.997*n)));
st.max  = e(end);
end
