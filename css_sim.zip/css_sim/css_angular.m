function f = css_angular(c, p, nonCos, useCutoff)
%CSS_ANGULAR Relative diode response vs. incidence angle.
%   c = cos(incidence angle) (any array shape, may be negative).
%   Ideal: f = max(c,0). Non-ideal: cosine times the Fresnel transmission
%   of the window (normalized to normal incidence), and zero beyond the
%   package cutoff angle (skipped if useCutoff = false, as the estimator
%   does so its model stays smooth). Replace with your measured curve.
if nargin < 4, useCutoff = true; end
c = max(c, 0);
if ~nonCos
    f = c;
    return
end
th = acos(min(c, 1));
n2 = p.diode.nGlass;
ti = asin(min(sin(th)/n2, 1));                       % refraction angle
rs = ((cos(th) - n2*cos(ti))./(cos(th) + n2*cos(ti))).^2;
rp = ((cos(ti) - n2*cos(th))./(cos(ti) + n2*cos(th))).^2;
T  = 1 - 0.5*(rs + rp);                              % unpolarized transmission
T0 = 1 - ((n2 - 1)/(n2 + 1))^2;
f  = c.*T/T0;
if useCutoff
    f(th > p.diode.cutoff_deg*pi/180) = 0;
end
end
