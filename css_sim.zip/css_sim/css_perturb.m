function Np = css_perturb(N, sig_deg)
%CSS_PERTURB Tilt each unit normal (row) by a random angle ~N(0, sig_deg)
%   about a random axis perpendicular to it.
Np = N;
for i = 1:size(N,1)
    n = N(i,:)';
    a = cross(n, randn(3,1));
    a = a/norm(a);
    t = sig_deg*pi/180*randn;
    Np(i,:) = (n*cos(t) + cross(a,n)*sin(t))';
end
end
