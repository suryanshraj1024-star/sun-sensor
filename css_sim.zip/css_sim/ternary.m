function out = ternary(cond, a, b)
%TERNARY Return a if cond is true, otherwise b.
if cond, out = a; else, out = b; end
end
