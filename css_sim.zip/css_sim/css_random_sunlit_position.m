function r = css_random_sunlit_position(p, sI)
%CSS_RANDOM_SUNLIT_POSITION Random orbit position outside Earth's shadow
%   (cylindrical shadow model).
a = p.env.Re + p.env.altitude;
while true
    v = randn(3,1);
    r = a*v/norm(v);
    along = r'*sI;
    if along > 0 || norm(r - along*sI) > p.env.Re
        return
    end
end
end
