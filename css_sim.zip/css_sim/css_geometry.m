function N = css_geometry(g)
%CSS_GEOMETRY Nominal unit normals (one row per diode) in the sensor frame.
%   Pyramid: nFaces faces tilted by beta from +Z, equally spaced in azimuth,
%   plus an optional top diode on +Z. Cube: one diode on each of +/-X,Y,Z.
switch lower(g.type)
    case 'pyramid'
        b  = g.beta_deg*pi/180;
        az = (0:g.nFaces-1)'*2*pi/g.nFaces;
        N  = [sin(b)*cos(az), sin(b)*sin(az), cos(b)*ones(g.nFaces,1)];
        if g.topDiode
            N = [N; 0 0 1];
        end
    case 'cube'
        N = [eye(3); -eye(3)];
    otherwise
        error('Unknown geometry type "%s"', g.type);
end
end
