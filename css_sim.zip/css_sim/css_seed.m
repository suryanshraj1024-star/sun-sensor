function css_seed(seed)
%CSS_SEED Seed the random generators (MATLAB and Octave).
try
    rng(seed);
catch
    rand('state', seed); randn('state', seed); %#ok<RAND>
end
end
