function F = css_frame(z)
%CSS_FRAME Right-handed rotation matrix whose third column is unit(z).
z = z(:)/norm(z);
if abs(z(1)) < 0.9, a = [1;0;0]; else, a = [0;1;0]; end
y = cross(z, a); y = y/norm(y);
x = cross(y, z);
F = [x y z];
end
