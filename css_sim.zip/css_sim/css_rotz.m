function R = css_rotz(a)
%CSS_ROTZ Rotation matrix about +Z by angle a (rad).
R = [cos(a) -sin(a) 0; sin(a) cos(a) 0; 0 0 1];
end
