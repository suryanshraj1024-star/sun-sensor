function EG = css_earthgrid(p, nRing, nAz)
%CSS_EARTHGRID Discretize the Earth cap visible from the satellite.
%   Cells are defined in a local frame whose +Z points to the satellite;
%   css_albedo rotates them to inertial. A fine grid under the satellite
%   is needed because the nearest cells dominate the albedo.
if nargin < 2, nRing = 60; end
if nargin < 3, nAz   = 72; end
a    = p.env.Re + p.env.altitude;
gmax = acos(p.env.Re/a);                 % Earth central angle of the horizon
dg   = gmax/nRing;
dphi = 2*pi/nAz;
g    = ((1:nRing)' - 0.5)*dg;
phi  = ((1:nAz) - 0.5)*dphi;
[G, PH] = ndgrid(g, phi);
G = G(:); PH = PH(:);
EG.Eloc = [sin(G).*cos(PH), sin(G).*sin(PH), cos(G)];
EG.dA   = p.env.Re^2*sin(G)*dg*dphi;
end
