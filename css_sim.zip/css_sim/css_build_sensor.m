function S = css_build_sensor(p)
%CSS_BUILD_SENSOR Create one "as-built" sensor unit.
%   S.Ntrue/S.gTrue are the real normals and gains (with manufacturing
%   errors); S.Nknown/S.gKnown are what the estimator believes after
%   calibration. Also sizes the TIA feedback resistor.
Nnom = css_geometry(p.geom);
nD   = size(Nnom,1);

if p.err.mismatch
    S.Ntrue = css_perturb(Nnom, p.geom.mountErr_deg);
    S.gTrue = 1 + p.diode.gainMismatch*randn(nD,1);
else
    S.Ntrue = Nnom;
    S.gTrue = ones(nD,1);
end

if p.err.mismatch && p.cal.calibrated
    S.Nknown = css_perturb(S.Ntrue, p.cal.normalResid_deg);
    S.gKnown = S.gTrue.*(1 + p.cal.gainResid*randn(nD,1));
else
    S.Nknown = Nnom;
    S.gKnown = ones(nD,1);
end

if p.err.offset
    S.Vos = p.elec.Vos*randn(nD,1);
else
    S.Vos = zeros(nD,1);
end
if p.cal.darkCorr
    S.VosKnown = S.Vos;    % measured in darkness / eclipse
else
    S.VosKnown = zeros(nD,1);
end

% Max direct-sun current at normal incidence (perihelion) and feedback resistor
S.Imax = p.diode.resp*p.diode.area*p.env.Esun*(1 + p.env.EsunVar);
S.Rf   = p.elec.Vfs/(p.elec.margin*S.Imax);
S.nD   = nD;
end
