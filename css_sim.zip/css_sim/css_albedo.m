function Ealb = css_albedo(rSat, sI, ND, Esun, p, EG)
%CSS_ALBEDO Earth-albedo irradiance on each diode (W/m^2, already
%   multiplied by the diode angular response, i.e. comparable to
%   Esun*css_angular(n.s)).
%   rSat: satellite position (inertial, m). sI: Sun unit vector (inertial).
%   ND: diode normals in the inertial frame (rows). Earth is modeled as a
%   Lambertian sphere with uniform albedo.
F = css_frame(rSat);
E = EG.Eloc*F';                                   % cell normals, inertial
M = size(E,1);
d  = repmat(rSat(:)', M, 1) - p.env.Re*E;         % cell -> satellite
dn = sqrt(sum(d.^2, 2));
u  = d./repmat(dn, 1, 3);
cosEmit = sum(E.*u, 2);
cosSun  = E*sI(:);
k  = cosEmit > 0 & cosSun > 0;                    % visible and sunlit cells
nD = size(ND,1);
if ~any(k)
    Ealb = zeros(nD,1);
    return
end
% Lambertian radiance * projected area / distance^2 = irradiance on a surface facing the cell
w    = p.env.albedo*Esun/pi*cosSun(k).*cosEmit(k).*EG.dA(k)./dn(k).^2;
cInc = -u(k,:)*ND';                               % incidence cosine on each diode
Ealb = (w'*css_angular(cInc, p, p.err.nonCosine))';
end
