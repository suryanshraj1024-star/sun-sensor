function [Td, Tmeas] = css_temps(nD, p, Tbase)
%CSS_TEMPS Diode temperatures and the temperature the electronics measure.
%   Tbase (optional): board temperature; otherwise drawn uniformly in
%   Tmean +/- Trange.
if ~p.err.temp
    Td = 25*ones(nD,1);
    Tmeas = 25;
    return
end
if nargin < 3
    Tbase = p.therm.Tmean + p.therm.Trange*(2*rand - 1);
end
Td    = Tbase + p.therm.gradient*randn(nD,1);
Tmeas = Tbase + p.therm.Tsensor_noise*randn;
end
