function R = css_montecarlo(p, EG)
%CSS_MONTECARLO Monte Carlo of Sun-vector error for the design in p.
%   Every sample builds a new sensor unit, draws a Sun direction uniformly
%   within p.sim.fovHalf_deg of the boresight, a temperature, a solar flux,
%   and (if albedo is on) a random sunlit orbit position and attitude.
%   R.err: angular error (deg, NaN when invalid), R.off: Sun off-boresight
%   angle (deg), R.valid, R.availability, R.stats (of valid samples).
if nargin < 2 || isempty(EG), EG = css_earthgrid(p); end
css_seed(p.sim.seed);
n     = p.sim.nSamples;
err   = nan(n,1);
off   = zeros(n,1);
valid = false(n,1);
cf    = cos(p.sim.fovHalf_deg*pi/180);
sI    = [1; 0; 0];                        % Sun direction, inertial

for k = 1:n
    S = css_build_sensor(p);
    ct = cf + (1 - cf)*rand;              % uniform on the spherical cap
    st = sqrt(1 - ct^2);
    ph = 2*pi*rand;
    sS = [st*cos(ph); st*sin(ph); ct];
    off(k) = acos(ct)*180/pi;

    Esun = p.env.Esun;
    if p.err.sunVar
        Esun = Esun*(1 + p.env.EsunVar*(2*rand - 1));
    end

    Ealb = zeros(S.nD,1);
    if p.err.albedo
        rSat  = css_random_sunlit_position(p, sI);
        R_s2i = css_frame(sI)*css_rotz(2*pi*rand)*css_frame(sS)';  % maps sS -> sI, random roll
        Ealb  = css_albedo(rSat, sI, (R_s2i*S.Ntrue')', Esun, p, EG);
    end

    [Td, Tmeas] = css_temps(S.nD, p);
    V = css_measure(S, sS, Ealb, Td, Esun, p);
    [sEst, ok] = css_estimate(V, S, Tmeas, p);
    valid(k) = ok;
    if ok
        err(k) = acos(max(-1, min(1, sEst'*sS)))*180/pi;
    end
end

R.err = err;
R.off = off;
R.valid = valid;
R.availability = mean(valid);
R.stats = css_stats(err(valid));
end
