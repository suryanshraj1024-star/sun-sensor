%RUN_ALL Run every CSS study in sequence. Each script also runs on its own.
%   Runtime: about 1-5 min in MATLAB (the beta trade is the longest).
run('css_error_budget.m');
run('css_trade_beta.m');
run('css_trade_adc.m');
run('css_orbit_sim.m');
