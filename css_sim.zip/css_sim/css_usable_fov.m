function fov = css_usable_fov(R, thr, binDeg)
%CSS_USABLE_FOV Largest off-boresight angle up to which every angular bin
%   has availability >= thr.
edges = 0:binDeg:90;
fov = 0;
for i = 1:numel(edges) - 1
    k = R.off >= edges(i) & R.off < edges(i+1);
    if ~any(k), continue; end
    if mean(R.valid(k)) < thr, break; end
    fov = edges(i+1);
end
end
